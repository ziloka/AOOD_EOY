import pygame

class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()

        #Camera offset
        self.offset = pygame.math.Vector2(0, 0)

        #Ground
        self.ground_surf = pygame.image.load('Sprites/ground.png').convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft = (0,0))

    def center_target_camera(self, target):
        self.offset.x = target.rect.centerx - self.display_surface.get_width() // 2
        self.offset.y = target.rect.centery - self.display_surface.get_height() // 2

    def custom_draw(self, player):
        self.center_target_camera(player)

        ground_offset = self.ground_rect.topleft - self.offset
        self.display_surface.blit(self.ground_surf,ground_offset)

        for sprite in sorted(self.sprites(), key=lambda sprite: sprite.rect.centery):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)