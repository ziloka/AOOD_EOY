import pygame

class Spritesheet:
    def __init__(self, filename, pos=(0, 0)):
        self.filename = filename
        self.sprite_sheet = pygame.image.load(filename).convert()
        self.transcolor = self.sprite_sheet.get_at(pos)
        print(self.transcolor)

    def get_sprite(self, x, y, w, h):
        sprite = pygame.Surface((w, h))
        sprite.blit(self.sprite_sheet, (0, 0), (x, y, w, h))
        sprite.set_colorkey(self.transcolor)
        return sprite